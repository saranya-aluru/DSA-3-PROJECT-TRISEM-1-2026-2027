# SimilarityLab (Advanced DSA, CO1–CO6)
    pip install -r requirements.txt
    streamlit run app.py
Files: app.py (landing + login/signup), auth.py (SQLite + PBKDF2), dashboard.py (analysis UI), engine.py (hand-built algorithms).
Accounts are stored in users.db (credentials only; documents are never saved).
